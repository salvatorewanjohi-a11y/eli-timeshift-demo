( function () {
	const cfg = window.ET || {};
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-US' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const heart = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.et-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'et-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		const t = document.createElement( 'div' );
		t.className = 'et-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3200 );
		setTimeout( () => t.remove(), 3700 );
	}
	document.body.addEventListener( 'wc-blocks_added_to_cart', () => toast( '✓ Added to your cart' ) );
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( '✓ Added to your cart' ) );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart (Interactivity API, or wp.data on
	// older WooCommerce); tell whichever is on the page to reload it.
	async function refreshMiniCart( cart ) {
		try {
			const { store } = await import( '@wordpress/interactivity' );
			const wc = store( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
	}

	async function addToCart( id, btn ) {
		if ( btn ) btn.disabled = true;
		try {
			if ( ! nonce ) await getCart();
			const res = await fetch( cfg.store + 'cart/add-item', {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/json', Nonce: nonce },
				body: JSON.stringify( { id: Number( id ), quantity: 1 } ),
			} );
			const cart = await res.json();
			if ( ! res.ok ) throw new Error( plain( cart.message || 'Could not add' ) );
			// Not awaited: the Interactivity API refresh can stay pending, which stalled multi-item adds.
			refreshMiniCart( cart );
			// The mini cart opens its drawer on this event; our toast listens too.
			document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true } ) );
			// The drawer can briefly re-show an older copy while it opens; refresh once more after.
			setTimeout( () => refreshMiniCart(), 900 );
		} catch ( e ) {
			toast( esc( e.message || 'Could not add to your cart. Please try again.' ) );
		} finally {
			if ( btn ) btn.disabled = false;
		}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-et-add]' );
		if ( ! b ) return;
		e.preventDefault();
		addToCart( b.dataset.etAdd, b );
	} );

	/* WhatsApp checkout -------------------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-et-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab now (inside the click) so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your cart is empty.' );
				return;
			}
			const lines = [ cart.items.length > 1 ? 'Hi Eli\'s TimeShiftKE, I\'d like these pieces:' : 'Hi Eli\'s TimeShiftKE, I\'d like this piece:' ];
			cart.items.forEach( ( it ) => {
				const opts = ( it.variation || [] ).map( ( v ) => v.value ).join( ', ' );
				lines.push( '• ' + plain( it.name ) + ( opts ? ' (' + opts + ')' : '' ) + ( it.quantity > 1 ? ' ×' + it.quantity : '' ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) ) );
			} );
			( cart.coupons || [] ).forEach( ( c ) => lines.push( 'Promo code: ' + c.code.toUpperCase() ) );
			lines.push( 'Total: ' + fmt( money( cart.totals.total_price, cart.totals ) ) );
			lines.push( 'Delivery to: ' );
			const url = 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your cart. Please try again.' );
		}
	} );

	/* Saved watches ------------------------------------------------------ */
	const KEY = 'et-wishlist';
	const readWish = () => {
		try {
			return JSON.parse( localStorage.getItem( KEY ) || '[]' ).map( Number ).filter( Boolean );
		} catch ( e ) {
			return [];
		}
	};
	const writeWish = ( ids ) => {
		try {
			localStorage.setItem( KEY, JSON.stringify( ids ) );
		} catch ( e ) {}
	};
	function paintWish() {
		const ids = readWish();
		// Only touch the DOM when something changed: the MutationObserver below calls this.
		$$( '[data-et-wish]' ).forEach( ( b ) => {
			const on = ids.includes( Number( b.dataset.etWish ) );
			if ( b.classList.contains( 'is-on' ) === on ) return;
			b.classList.toggle( 'is-on', on );
			b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
		} );
		$$( '[data-et-wish-count]' ).forEach( ( el ) => {
			if ( el.textContent !== String( ids.length ) ) el.textContent = ids.length;
			el.hidden = ids.length === 0;
		} );
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-et-wish]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const id = Number( b.dataset.etWish );
		let ids = readWish();
		const on = ids.includes( id );
		ids = on ? ids.filter( ( x ) => x !== id ) : [ ...ids, id ];
		writeWish( ids );
		paintWish();
		toast( on ? 'Removed from your wishlist' : '♥ Saved to <a href="' + esc( cfg.home || '/' ) + 'wishlist/">your wishlist</a>' );
		if ( b.closest( '[data-et-wishlist]' ) ) renderWishlist();
	} );

	async function renderWishlist() {
		const box = document.querySelector( '[data-et-wishlist]' );
		if ( ! box ) return;
		const ids = readWish();
		if ( ! ids.length ) {
			box.innerHTML = '<div class="et-empty"><p>Nothing saved yet. Tap the ♥ on any watch to keep it here.</p><a class="wp-element-button" href="' + esc( cfg.shop || '/shop/' ) + '">Browse the collection</a></div>';
			return;
		}
		try {
			const res = await fetch( cfg.store + 'products?include=' + ids.join( ',' ) + '&per_page=50' );
			const items = await res.json();
			box.innerHTML = '<div class="et-wish-grid">' + items.map( ( p ) => {
				const img = p.images && p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail || p.images[ 0 ].src ) + '" alt="" loading="lazy">' : '';
				return '<article class="et-wish-card"><a href="' + esc( p.permalink ) + '">' + img + '</a>' +
					'<button type="button" class="et-heart is-on" data-et-wish="' + p.id + '" aria-label="Remove from wishlist" aria-pressed="true">' + heart + '</button>' +
					'<h3><a href="' + esc( p.permalink ) + '">' + p.name + '</a></h3><div class="et-wish-price">' + p.price_html + '</div>' +
					( p.is_purchasable && ( p.is_in_stock || p.is_on_backorder ) ? '<button type="button" class="wp-element-button" data-et-add="' + p.id + '">' + ( p.is_on_backorder ? 'Pre-order' : 'Add to cart' ) + '</button>' : '<a class="wp-element-button" href="' + esc( p.permalink ) + '">View</a>' ) + '</article>';
			} ).join( '' ) + '</div>';
		} catch ( e ) {
			box.innerHTML = '<p>Could not load your wishlist. Please refresh the page.</p>';
		}
	}

	/* Quick view --------------------------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-et-qv]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const dlg = document.getElementById( 'et-qv' );
		const body = dlg && dlg.querySelector( '[data-et-qv-body]' );
		if ( ! body || ! dlg.showModal ) return;
		body.innerHTML = '<p class="et-small">Loading…</p>';
		dlg.showModal();
		try {
			const p = await ( await fetch( cfg.store + 'products/' + b.dataset.etQv ) ).json();
			const imgs = ( p.images || [] ).map( ( im, i ) => '<img src="' + esc( im.src ) + '" alt="' + esc( im.alt || plain( p.name ) ) + '"' + ( i ? ' hidden' : '' ) + '>' ).join( '' );
			const thumbs = ( p.images || [] ).length > 1 ? '<div class="et-qv__thumbs">' + p.images.map( ( im, i ) => '<button type="button" data-et-qv-img="' + i + '"><img src="' + esc( im.thumbnail || im.src ) + '" alt=""></button>' ).join( '' ) + '</div>' : '';
			const brand = p.categories && p.categories[ 0 ] ? p.categories[ 0 ].name : '';
			const variable = p.type === 'variable';
			const buy = variable
				? '<a class="wp-element-button" href="' + esc( p.permalink ) + '">Choose dial</a>'
				: p.is_purchasable && ( p.is_in_stock || p.is_on_backorder )
					? '<button type="button" class="wp-element-button" data-et-add="' + p.id + '">' + ( p.is_on_backorder ? 'Pre-order this piece' : 'Add to cart' ) + '</button>'
					: '<span class="et-badge et-badge--out">Sold out</span>';
			body.innerHTML = '<div class="et-qv__grid"><div class="et-qv__media"><div class="et-qv__main">' + imgs + '</div>' + thumbs + '</div>' +
				'<div class="et-qv__info">' + ( brand ? '<p class="et-eyebrow">' + esc( plain( brand ) ) + '</p>' : '' ) + '<h2>' + p.name + '</h2><div class="et-qv__price">' + p.price_html + '</div>' +
				( p.is_on_backorder ? '<div class="et-badges"><span class="et-badge et-badge--order">PRE-ORDER$</span></div>' : '' ) +
				'<div class="et-qv__desc">' + ( p.short_description || '' ) + '</div>' +
				'<div class="et-qv__actions">' + buy + '<a class="et-link" href="' + esc( p.permalink ) + '">Full specifications →</a></div></div></div>';
		} catch ( err ) {
			body.innerHTML = '<p>Could not load this watch. Please try again.</p>';
		}
	} );
	document.addEventListener( 'click', ( e ) => {
		const t = e.target.closest( '[data-et-qv-img]' );
		if ( ! t ) return;
		const main = t.closest( '.et-qv__media' ).querySelectorAll( '.et-qv__main img' );
		main.forEach( ( im, i ) => ( im.hidden = i !== Number( t.dataset.etQvImg ) ) );
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.et-dialog' ) ) e.target.close();
	} );

	/* Instant search ----------------------------------------------------- */
	function initSearch() {
		$$( '.et-search input[type="search"]' ).forEach( ( input ) => {
			const form = input.closest( 'form' );
			const list = document.createElement( 'div' );
			list.className = 'et-suggest';
			list.hidden = true;
			form.style.position = 'relative';
			form.appendChild( list );
			let timer;
			let seq = 0;
			input.setAttribute( 'autocomplete', 'off' );
			input.addEventListener( 'input', () => {
				clearTimeout( timer );
				const q = input.value.trim();
				if ( q.length < 2 ) {
					list.hidden = true;
					return;
				}
				timer = setTimeout( async () => {
					const mine = ++seq;
					try {
						const res = await fetch( cfg.store + 'products?search=' + encodeURIComponent( q ) + '&per_page=6' );
						const items = await res.json();
						if ( mine !== seq ) return;
						list.innerHTML = items.length
							? items.map( ( p ) => '<a href="' + esc( p.permalink ) + '">' + ( p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail ) + '" alt="">' : '' ) + '<span>' + p.name + '<small>' + p.price_html + '</small></span></a>' ).join( '' ) + '<button type="submit">See all results for “' + esc( q ) + '”</button>'
							: '<p>Nothing in the shop matches “' + esc( q ) + '”. <a href="https://wa.me/' + esc( cfg.wa ) + '?text=' + encodeURIComponent( 'Hi Eli\'s TimeShiftKE, can you source a ' + q + '?' ) + '">Ask our sourcing desk</a></p>';
						list.hidden = false;
					} catch ( e ) {}
				}, 180 );
			} );
			document.addEventListener( 'click', ( e ) => {
				if ( ! form.contains( e.target ) ) list.hidden = true;
			} );
			input.addEventListener( 'keydown', ( e ) => {
				if ( e.key === 'Escape' ) list.hidden = true;
			} );
		} );
	}

	/* Dial swatches on cards: swap the card photo ------------------------- */
	document.addEventListener( 'click', ( e ) => {
		const s = e.target.closest( '[data-et-swatch]' );
		if ( ! s ) return;
		e.preventDefault();
		const card = s.closest( '.wc-block-product, li, article' );
		const img = card && card.querySelector( '.wc-block-components-product-image img:not(.et-alt-img)' );
		if ( img && s.dataset.etSwatch ) {
			img.removeAttribute( 'srcset' );
			img.removeAttribute( 'sizes' );
			img.src = s.dataset.etSwatch;
		}
		$$( '[data-et-swatch]', s.parentNode ).forEach( ( x ) => x.classList.toggle( 'is-on', x === s ) );
	} );

	/* Dial swatches on the product page: buttons that drive the dial select ---- */
	function initDialPicker() {
		$$( 'form.variations_form select[name="attribute_dial"]' ).forEach( ( sel ) => {
			const row = document.createElement( 'div' );
			row.className = 'et-swatches et-swatches--pd';
			Array.from( sel.options ).filter( ( o ) => o.value ).forEach( ( o ) => {
				const b = document.createElement( 'button' );
				b.type = 'button';
				b.className = 'et-swatch' + ( o.selected ? ' is-on' : '' );
				b.style.setProperty( '--c', ( cfg.dials || {} )[ o.value ] || '#888' );
				b.title = o.value;
				b.setAttribute( 'aria-label', o.value + ' dial' );
				b.addEventListener( 'click', () => {
					sel.value = o.value;
					sel.dispatchEvent( new Event( 'change', { bubbles: true } ) );
					if ( window.jQuery ) window.jQuery( sel ).trigger( 'change' );
					$$( '.et-swatch', row ).forEach( ( x ) => x.classList.toggle( 'is-on', x === b ) );
				} );
				row.appendChild( b );
			} );
			sel.insertAdjacentElement( 'beforebegin', row );
		} );
	}

	/* Collector Box upsell -------------------------------------------------- */
	document.addEventListener( 'change', ( e ) => {
		const box = e.target.closest( '[data-et-box]' );
		if ( ! box ) return;
		const btn = box.querySelector( '[data-et-box-add]' );
		const n = $$( 'input:checked', box ).length;
		btn.disabled = n === 0;
		btn.textContent = n ? 'Add ' + n + ' to cart' : 'Add selected to cart';
	} );
	document.addEventListener( 'click', async ( e ) => {
		const btn = e.target.closest( '[data-et-box-add]' );
		if ( ! btn ) return;
		const box = btn.closest( '[data-et-box]' );
		const ids = $$( 'input:checked', box ).map( ( i ) => i.value );
		for ( const id of ids ) await addToCart( id, btn, true );
		$$( 'input:checked', box ).forEach( ( i ) => ( i.checked = false ) );
		btn.disabled = true;
		btn.textContent = 'Add selected to cart';
	} );

	/* Sourcing desk: pop-up and form ---------------------------------------- */
	document.addEventListener( 'click', ( e ) => {
		const a = e.target.closest( '[data-et-src-open]' );
		const dlg = document.getElementById( 'et-src' );
		if ( ! a || ! dlg || ! dlg.showModal ) return;
		e.preventDefault();
		dlg.showModal();
	} );
	document.addEventListener( 'submit', async ( e ) => {
		const form = e.target.closest( '[data-et-src-form]' );
		if ( ! form ) return;
		e.preventDefault();
		const btn = form.querySelector( 'button[type="submit"]' );
		btn.disabled = true;
		btn.textContent = 'Sending…';
		try {
			const data = new FormData( form );
			data.append( 'ajax', '1' );
			// getAttribute: the hidden "action" input shadows form.action.
			const res = await fetch( form.getAttribute( 'action' ), { method: 'POST', body: data, credentials: 'same-origin' } );
			const json = await res.json();
			if ( ! json.success ) throw new Error( ( json.data && json.data.message ) || 'Could not send your request.' );
			form.outerHTML = '<div class="et-src-done"><p class="et-eyebrow">Request received ✓</p><h3>Reference ' + esc( json.data.code ) + '</h3><p>Our sourcing desk has your request. For the fastest reply, send it to us on WhatsApp as well.</p><a class="wp-element-button et-wa-btn" href="' + esc( json.data.wa ) + '" target="_blank" rel="noopener">Send request on WhatsApp</a></div>';
			toast( '✓ Sourcing request ' + esc( json.data.code ) + ' sent' );
		} catch ( err ) {
			btn.disabled = false;
			btn.textContent = 'Send sourcing request';
			toast( esc( err.message || 'Could not send your request. Please try again.' ) );
		}
	} );

	/* Promo codes: confirm in a toast when one is applied ------------------- */
	let coupons = null;
	function watchCoupons() {
		const data = window.wp && window.wp.data;
		if ( ! data || ! data.select( 'wc/store/cart' ) ) return;
		data.subscribe( () => {
			const list = ( data.select( 'wc/store/cart' ).getCartData().coupons || [] ).map( ( c ) => c.code );
			if ( coupons !== null ) list.filter( ( c ) => ! coupons.includes( c ) ).forEach( ( c ) => toast( '✓ Promo code ' + esc( c.toUpperCase() ) + ' applied' ) );
			coupons = list;
		} );
	}

	function init() {
		paintWish();
		renderWishlist();
		initSearch();
		initDialPicker();
		setTimeout( watchCoupons, 800 );
		// Cards re-render client-side in some blocks; keep hearts in sync.
		new MutationObserver( () => paintWish() ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();

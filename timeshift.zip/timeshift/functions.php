<?php
/**
 * Eli's TimeShiftKE child theme.
 */

const ET_WHATSAPP  = '254748370617';
const ET_PHONE     = '+254 748 370 617';
const ET_INSTAGRAM = 'elistimeshiftke';
const ET_FONTS     = 'https://fonts.googleapis.com/css2?family=Bodoni+Moda:ital,opsz,wght@0,6..96,500;0,6..96,600;0,6..96,700;1,6..96,500&family=Manrope:wght@400;500;600;700;800&display=swap';
const ET_BUNDLE    = 0.10; // Collector Box discount when bought with a watch.

// Swatch colours for the dial options.
const ET_DIALS = [
	'Silver' => '#d9d6cf', 'Navy' => '#22396e', 'Black' => '#15171a', 'Blue' => '#1f4aa8', 'Green' => '#24724a',
	'Pink'   => '#e9a3bc', 'Teal' => '#3fb2b0', 'Mint' => '#8fd3a8',
];

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'et-fonts', ET_FONTS, [], null );
	wp_enqueue_style( 'et', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'et', $uri . '/assets/et.js', [], filemtime( $dir . '/assets/et.js' ), true );
	wp_localize_script( 'et', 'ET', [
		'store'    => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'     => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'home'     => esc_url_raw( home_url( '/' ) ),
		'cart'     => esc_url_raw( wc_get_cart_url() ),
		'post'     => esc_url_raw( admin_url( 'admin-post.php' ) ),
		'wa'       => ET_WHATSAPP,
		'dials'    => ET_DIALS,
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'et-fonts', ET_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

// Movement and strap pages (/movement/automatic/) need rewrite rules made after the attributes exist.
add_action( 'init', function () {
	if ( get_option( 'et_rewrites' ) !== '1' && taxonomy_exists( 'pa_movement' ) ) {
		flush_rewrite_rules();
		update_option( 'et_rewrites', '1' );
	}
}, 99 );

// WooCommerce's symbol for Kenyan shillings is "KSh", the way shops here write it.
add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );

function et_wa_link( $text = '' ) {
	return 'https://wa.me/' . ET_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}

function et_money( $amount ) {
	return 'KSh ' . number_format( (float) $amount );
}

/**
 * Specs as label => value pairs, from the "Label: value" lines on the product screen.
 */
function et_specs( $product_id ) {
	$out = [];
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_et_specs', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] !== '' ) {
			$out[ $parts[0] ] = $parts[1];
		}
	}
	return $out;
}

function et_base_id( WC_Product $product ) {
	return $product->get_parent_id() ?: $product->get_id();
}

function et_is_sample( WC_Product $product ) {
	return get_post_meta( et_base_id( $product ), '_et_sample', true ) === 'yes';
}

function et_is_accessory( WC_Product $product ) {
	return has_term( 'collector-box', 'product_cat', et_base_id( $product ) );
}

/** "ready", "order" or "" from the product's availability tag and stock. */
function et_availability( WC_Product $product ) {
	$id = et_base_id( $product );
	if ( has_term( 'pre-order', 'product_tag', $id ) || ( $product->managing_stock() && $product->is_on_backorder() ) ) {
		return 'order';
	}
	if ( $product->is_in_stock() && has_term( 'in-stores', 'product_tag', $id ) ) {
		return 'ready';
	}
	return '';
}

function et_attr_names( WC_Product $product, $tax ) {
	$names = wc_get_product_terms( et_base_id( $product ), $tax, [ 'fields' => 'names' ] );
	return is_wp_error( $names ) ? [] : $names;
}

function et_badges_html( WC_Product $product ) {
	$h = '';
	$avail = et_availability( $product );
	if ( ! $product->is_in_stock() ) {
		$h .= '<span class="et-badge et-badge--out">Sold out</span>';
	} elseif ( $avail === 'ready' ) {
		$h .= '<span class="et-badge et-badge--ready">In $tores · Nairobi</span>';
	} elseif ( $avail === 'order' ) {
		$h .= '<span class="et-badge et-badge--order">PRE-ORDER$</span>';
	}
	foreach ( et_attr_names( $product, 'pa_movement' ) as $m ) {
		$h .= '<span class="et-badge">' . esc_html( $m ) . '</span>';
	}
	if ( et_is_sample( $product ) ) {
		$h .= '<span class="et-badge et-badge--sample" title="Demo listing: Eli\'s real stock replaces it">Sample</span>';
	}
	return $h ? '<div class="et-badges">' . $h . '</div>' : '';
}

/** Percentage saved on products on sale. */
function et_saving( WC_Product $product ) {
	if ( ! $product->is_on_sale() || ! $product->is_type( 'simple' ) ) {
		return 0;
	}
	$reg = (float) $product->get_regular_price();
	return $reg > 0 ? (int) round( ( 1 - (float) $product->get_sale_price() / $reg ) * 100 ) : 0;
}

// Pre-order pieces are reserved rather than bought outright.
add_filter( 'woocommerce_product_single_add_to_cart_text', fn( $t, $p ) => $p && et_availability( $p ) === 'order' ? 'Pre-order this piece' : 'Add to cart', 10, 2 );
add_filter( 'woocommerce_product_add_to_cart_text', function ( $t, $p ) {
	if ( ! $p || ! $p->is_purchasable() || ! $p->is_in_stock() ) {
		return $t;
	}
	if ( $p->is_type( 'variable' ) ) {
		return 'Choose dial';
	}
	return et_availability( $p ) === 'order' ? 'Pre-order' : 'Add to cart';
}, 10, 2 );
add_filter( 'woocommerce_get_availability_text', function ( $text, $product ) {
	if ( $product->is_on_backorder() ) {
		return 'PRE-ORDER$ – we confirm the arrival date when we call';
	}
	if ( $product->is_in_stock() ) {
		$n = $product->get_stock_quantity();
		return 'In $tores, Nairobi' . ( $n && $n <= 3 ? ' – only ' . $n . ' left' : '' );
	}
	return 'Sold out – ask us to source one';
}, 10, 2 );

/* -------------------------------------------------------------------------
 * Product page
 * ---------------------------------------------------------------------- */

const ET_WA_ICON = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';

function et_source_url( WC_Product $product ) {
	return add_query_arg( 'like', rawurlencode( $product->get_name() ), home_url( '/sourcing-desk/' ) ) . '#source';
}

// Sample notice and key specs above the add-to-cart button.
add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	if ( et_is_sample( $product ) ) {
		echo '<p class="et-sample-note"><strong>Sample listing.</strong> This drawn watch shows how the shop works. Eli\'s real stock goes here before launch.</p>';
	}
	$specs = et_specs( $product->get_id() );
	$keys  = array_intersect_key( $specs, array_flip( [ 'Case', 'Movement', 'Water resistance', 'Glass' ] ) );
	if ( ! $keys ) {
		return;
	}
	echo '<ul class="et-keyspecs">';
	foreach ( $keys as $k => $v ) {
		echo '<li><span>' . esc_html( $k ) . '</span><strong>' . esc_html( $v ) . '</strong></li>';
	}
	echo '</ul>';
} );

// WhatsApp, sourcing, Collector Box upsell and buying promises under the add-to-cart button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$msg = 'Hi Eli\'s TimeShiftKE, I\'m interested in the ' . $product->get_name() . ' (' . et_money( $product->get_price() ) . '). ' . $product->get_permalink();
	echo '<div class="et-pd-actions"><a class="et-wa-order" href="' . esc_url( et_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . ET_WA_ICON . 'Order on WhatsApp</a>';
	if ( ! et_is_accessory( $product ) ) {
		echo '<a class="et-source-btn" href="' . esc_url( et_source_url( $product ) ) . '">Source a similar piece 🔌</a>';
	}
	echo '</div>';

	if ( ! et_is_accessory( $product ) ) {
		echo et_collector_box_html();
	}

	echo '<div class="et-promise"><div><span aria-hidden="true">📦</span><p><strong>Payment on delivery</strong>Pay by M-Pesa or cash once the watch is in your hand.</p></div><div><span aria-hidden="true">🔌</span><p><strong>Free delivery in Nairobi</strong>Countrywide parcels too, we call to arrange the courier.</p></div><div><span aria-hidden="true">✦</span><p><strong>Complimentary packaging</strong>Every piece comes boxed, ready to give.</p></div></div>';
} );

/** "Complete the Collector Box": accessories with a bundle discount when added with a watch. */
function et_collector_box_html() {
	$items = wc_get_products( [ 'category' => [ 'collector-box' ], 'limit' => 6, 'orderby' => 'menu_order', 'order' => 'ASC', 'status' => 'publish', 'stock_status' => 'instock' ] );
	if ( ! $items ) {
		return '';
	}
	$h = '<div class="et-box" data-et-box><p class="et-box__title">Complete the Collector Box <em>' . (int) ( ET_BUNDLE * 100 ) . '% off with a watch</em></p><ul>';
	foreach ( $items as $p ) {
		$h .= sprintf(
			'<li><label><input type="checkbox" value="%1$d"> %2$s<span class="et-box__name">%3$s</span><span class="et-box__price"><del>%4$s</del> %5$s</span></label></li>',
			$p->get_id(),
			$p->get_image( [ 56, 56 ], [ 'alt' => '', 'loading' => 'lazy' ] ),
			esc_html( $p->get_name() ),
			esc_html( et_money( $p->get_price() ) ),
			esc_html( et_money( $p->get_price() * ( 1 - ET_BUNDLE ) ) )
		);
	}
	return $h . '</ul><button type="button" class="et-box__add" data-et-box-add disabled>Add selected to cart</button><p class="et-box__note">The discount shows in your cart when there\'s a watch in it.</p></div>';
}

// The bundle discount itself.
add_action( 'woocommerce_cart_calculate_fees', function ( WC_Cart $cart ) {
	$watch = false;
	$acc   = 0;
	foreach ( $cart->get_cart() as $item ) {
		if ( et_is_accessory( $item['data'] ) ) {
			$acc += (float) $item['line_subtotal'];
		} else {
			$watch = true;
		}
	}
	if ( $watch && $acc > 0 ) {
		$cart->add_fee( 'Collector Box bundle (' . (int) ( ET_BUNDLE * 100 ) . '% off accessories)', -round( $acc * ET_BUNDLE ), false );
	}
} );

// Specs, care and delivery tabs (the reviews tab stays: only verified buyers can review).
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) {
		return $tabs;
	}
	$specs = et_specs( $product->get_id() );
	if ( $specs ) {
		$tabs['et_specs'] = [
			'title'    => 'Specifications',
			'priority' => 5,
			'callback' => function () use ( $specs ) {
				echo '<table class="et-spec-table"><tbody>';
				foreach ( $specs as $k => $v ) {
					echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
				}
				echo '</tbody></table>';
			},
		];
	}
	$tabs['et_care'] = [
		'title'    => 'Care',
		'priority' => 25,
		'callback' => function () {
			echo '<ul><li><strong>Automatic watches</strong> wind themselves as you wear them. If one stops after a few days in the drawer, wind it 20–30 turns at the crown, or keep it on a watch winder.</li><li><strong>Quartz watches</strong> run on a battery for 2–3 years. When the seconds hand starts jumping in fours, it\'s time for a new battery.</li><li><strong>Water resistance</strong> is a pressure test, not a diving depth. Keep the crown pushed or screwed in, and rinse in fresh water after the pool or the sea.</li><li><strong>Magnets</strong> from speakers, laptops and phone cases can make an automatic run fast. Keep it a hand\'s width away.</li><li><strong>Leather straps</strong> don\'t like water or sweat. Rubber and steel do, so swap for the gym or the beach.</li></ul>';
		},
	];
	$tabs['et_delivery'] = [
		'title'    => 'Delivery & payment',
		'priority' => 30,
		'callback' => function () {
			echo '<ul><li><strong>Payment on delivery 📦</strong> Pay by M-Pesa or cash once the watch is in your hand. We call to confirm the order first.</li><li><strong>Nairobi:</strong> free delivery 🔌 at a time that suits you.</li><li><strong>Outside Nairobi:</strong> countrywide parcel. We call to agree the courier and timing.</li><li><strong>PRE-ORDER$:</strong> order now and we confirm the arrival date before anything else happens.</li><li><strong>Packaging:</strong> every piece comes boxed, at no extra cost.</li></ul>';
		},
	];
	// The description already shows next to the photos.
	unset( $tabs['description'], $tabs['additional_information'] );
	return $tabs;
}, 20 );

// Reviews tab: an honest empty state until real buyers review.
add_filter( 'gettext', function ( $t, $text, $domain ) {
	if ( $domain === 'woocommerce' && $text === 'There are no reviews yet.' ) {
		return 'No reviews yet. Reviews come from verified buyers after delivery.';
	}
	return $t;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Product cards
 * ---------------------------------------------------------------------- */

function et_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

const ET_HEART = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';

// Hover image (first gallery photo), sale badge, wishlist heart and quick view on product images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = et_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'et-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$off   = et_saving( $product );
	$extra = $off ? '<span class="et-off">−' . $off . '%</span>' : '';
	$extra .= sprintf(
		'<button type="button" class="et-heart" data-et-wish="%1$d" aria-label="Save %2$s to your wishlist" aria-pressed="false">%3$s</button><button type="button" class="et-qv-btn" data-et-qv="%1$d" aria-label="Quick view of %2$s">Quick view</button>',
		$product->get_id(),
		esc_attr( $product->get_name() ),
		ET_HEART
	);
	$pos = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $extra . '</div>', $pos, 6 );
}, 10, 3 );

// Collection above the title.
add_filter( 'render_block_core/post-title', function ( $content, $block, $instance ) {
	if ( empty( $block['attrs']['__woocommerceNamespace'] ) ) {
		return $content;
	}
	$product = et_card_product( $instance );
	$cats    = $product ? wp_get_post_terms( $product->get_id(), 'product_cat', [ 'fields' => 'names' ] ) : [];
	return ( $cats && ! is_wp_error( $cats ) ? '<p class="et-card-cat">' . esc_html( $cats[0] ) . '</p>' : '' ) . $content;
}, 10, 3 );

// Availability, movement and dial swatches above the price.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = et_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	return et_badges_html( $product ) . et_swatches_html( $product ) . $content;
}, 10, 3 );

/** Dial swatches for variable watches; each one swaps the card photo (et.js). */
function et_swatches_html( WC_Product $product ) {
	if ( ! $product->is_type( 'variable' ) ) {
		return '';
	}
	$h = '';
	foreach ( $product->get_children() as $vid ) {
		$v = wc_get_product( $vid );
		if ( ! $v || ! $v->is_purchasable() ) {
			continue;
		}
		$dial = $v->get_attribute( 'dial' );
		$src  = wp_get_attachment_image_url( $v->get_image_id(), 'woocommerce_thumbnail' );
		$h   .= sprintf(
			'<button type="button" class="et-swatch" style="--c:%1$s" data-et-swatch="%2$s" aria-label="%3$s dial" title="%3$s"></button>',
			esc_attr( ET_DIALS[ $dial ] ?? '#888' ),
			esc_url( $src ?: '' ),
			esc_attr( $dial )
		);
	}
	return $h ? '<div class="et-swatches">' . $h . '</div>' : '';
}

// "Source similar" under the card button.
add_filter( 'render_block_woocommerce/product-button', function ( $content, $block, $instance ) {
	$product = et_card_product( $instance );
	if ( ! $product || et_is_accessory( $product ) ) {
		return $content;
	}
	return $content . '<a class="et-card-source" href="' . esc_url( et_source_url( $product ) ) . '">Source similar piece →</a>';
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page and shop sections
 * ---------------------------------------------------------------------- */

function et_categories( $with_box = true ) {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	if ( is_wp_error( $terms ) ) {
		return [];
	}
	return $with_box ? $terms : array_values( array_filter( $terms, fn( $t ) => $t->slug !== 'collector-box' ) );
}

function et_first_image( $args ) {
	$first = wc_get_products( $args + [ 'limit' => 1, 'orderby' => 'menu_order', 'order' => 'ASC', 'status' => 'publish' ] );
	return $first ? $first[0]->get_image( 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) : '';
}

// Instagram-style highlight circles: Eli's collections, availability and the sourcing desk.
add_shortcode( 'et_highlights', function () {
	$items = [];
	$in = get_term_by( 'slug', 'in-stores', 'product_tag' );
	if ( $in && $in->count ) {
		$items[] = [ get_term_link( $in ), 'In $tores', et_first_image( [ 'tag' => [ 'in-stores' ] ] ) ];
	}
	foreach ( et_categories( false ) as $t ) {
		$items[] = [ get_term_link( $t ), $t->name, et_first_image( [ 'category' => [ $t->slug ] ] ) ];
	}
	$pre = get_term_by( 'slug', 'pre-order', 'product_tag' );
	if ( $pre && $pre->count ) {
		$items[] = [ get_term_link( $pre ), 'PRE-ORDER$', et_first_image( [ 'tag' => [ 'pre-order' ] ] ) ];
	}
	$items[] = [ home_url( '/sourcing-desk/' ), 'Sourcing 🔌', '<img src="' . esc_url( get_stylesheet_directory_uri() . '/assets/photos/sourcing.webp' ) . '" alt="" loading="lazy">' ];
	$h = '<nav class="et-hl" aria-label="Collections">';
	foreach ( $items as [ $url, $label, $img ] ) {
		$h .= '<a class="et-hl__item" href="' . esc_url( $url ) . '"><span class="et-hl__ring">' . $img . '</span><span class="et-hl__label">' . esc_html( $label ) . '</span></a>';
	}
	return $h . '</nav>';
} );

// "Shop by collection": one tile per collection, shown with a photo of its first watch.
add_shortcode( 'et_styles', function () {
	$h = '<div class="et-styles">';
	foreach ( et_categories( false ) as $t ) {
		$h .= sprintf(
			'<a class="et-style" href="%s"><span class="et-style__img">%s</span><span class="et-style__txt"><strong>%s</strong><em>%s</em></span></a>',
			esc_url( get_term_link( $t ) ),
			et_first_image( [ 'category' => [ $t->slug ] ] ),
			esc_html( $t->name ),
			esc_html( sprintf( _n( '%d piece', '%d pieces', $t->count ), $t->count ) )
		);
	}
	return $h . '</div>';
} );

function et_chip( $label, $url, $on, $count = null, $small = false ) {
	return sprintf( '<a class="et-chip%s%s" href="%s">%s%s</a>', $small ? ' et-chip--sm' : '', $on ? ' is-on' : '', esc_url( $url ), esc_html( $label ), $count === null ? '' : ' <em>' . (int) $count . '</em>' );
}

function et_attr_terms( $tax ) {
	if ( ! taxonomy_exists( $tax ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => $tax, 'hide_empty' => true, 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

// Collection, availability, movement and strap chips above shop, collection, tag and search results.
add_shortcode( 'et_filters', function () {
	$current = get_queried_object();
	$cur_id  = $current instanceof WP_Term ? $current->term_id : 0;
	$h = '<nav class="et-filters" aria-label="Filter timepieces"><div class="et-filters__row">';
	$h .= et_chip( 'All timepieces', wc_get_page_permalink( 'shop' ), is_shop() );
	foreach ( et_categories() as $t ) {
		$h .= et_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, $t->count );
	}
	$h .= '</div><div class="et-filters__row"><span>Availability</span>';
	foreach ( [ 'in-stores', 'pre-order' ] as $slug ) {
		$t = get_term_by( 'slug', $slug, 'product_tag' );
		if ( $t && $t->count ) {
			$h .= et_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, $t->count, true );
		}
	}
	foreach ( [ 'pa_movement' => 'Movement', 'pa_strap' => 'Strap' ] as $tax => $label ) {
		$terms = et_attr_terms( $tax );
		if ( ! $terms ) {
			continue;
		}
		$h .= '</div><div class="et-filters__row"><span>' . esc_html( $label ) . '</span>';
		foreach ( $terms as $t ) {
			$link = get_term_link( $t );
			if ( ! is_wp_error( $link ) ) {
				$h .= et_chip( $t->name, $link, $t->term_id === $cur_id, $t->count, true );
			}
		}
	}
	return $h . '</div></nav>';
} );

// Attribute pages (/movement/automatic/) get a readable title.
add_filter( 'get_the_archive_title', function ( $title ) {
	if ( is_tax( 'pa_movement' ) ) {
		return single_term_title( '', false ) . ' watches';
	}
	if ( is_tax( 'pa_strap' ) ) {
		return 'On ' . strtolower( single_term_title( '', false ) );
	}
	return $title;
} );

add_shortcode( 'et_wishlist', function () {
	return '<div class="et-wishlist" data-et-wishlist><p class="et-small">Loading your saved pieces…</p></div>';
} );

// Quick view and sourcing pop-ups, filled in by et.js.
add_action( 'wp_footer', function () {
	echo '<dialog id="et-qv" class="et-dialog et-qv" aria-label="Quick view"><form method="dialog"><button class="et-dialog__close" aria-label="Close">×</button></form><div data-et-qv-body></div></dialog>';
	echo '<dialog id="et-src" class="et-dialog et-dialog--narrow" aria-label="Request a piece"><form method="dialog"><button class="et-dialog__close" aria-label="Close">×</button></form><p class="et-eyebrow">Sourcing desk 🔌</p><h2>Tell us the piece you want</h2>' . et_sourcing_form( true ) . '</dialog>';
} );

/* -------------------------------------------------------------------------
 * Sourcing desk: requests with a reference photo, kept for Eli under "Sourcing requests"
 * ---------------------------------------------------------------------- */

add_action( 'init', function () {
	register_post_type( 'et_request', [
		'label'           => 'Sourcing requests',
		'labels'          => [ 'name' => 'Sourcing requests', 'singular_name' => 'Sourcing request', 'edit_item' => 'Sourcing request' ],
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'menu_icon'       => 'dashicons-search',
		'menu_position'   => 56,
		'supports'        => [ 'title', 'editor' ],
		'capability_type' => 'post',
		'capabilities'    => [ 'create_posts' => 'do_not_allow' ],
		'map_meta_cap'    => true,
	] );
} );

function et_sourcing_form( $compact = false ) {
	$like = sanitize_text_field( wp_unslash( $_GET['like'] ?? '' ) );
	$want = $like ? 'Something like the ' . $like : '';
	return '<form class="et-src-form" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" data-et-src-form>'
		. '<input type="hidden" name="action" value="et_source">'
		. wp_nonce_field( 'et_source', '_wpnonce', true, false )
		. '<label class="et-field et-field--wide"><span>The watch you want</span><input name="want" required value="' . esc_attr( $want ) . '" placeholder="Model, colour, size, or describe it"></label>'
		. '<label class="et-field"><span>Your name</span><input name="name" required autocomplete="name"></label>'
		. '<label class="et-field"><span>Phone / WhatsApp</span><input name="phone" type="tel" required autocomplete="tel" placeholder="07XX XXX XXX"></label>'
		. '<label class="et-field"><span>Budget</span><select name="budget"><option>Under KSh 25,000</option><option selected>KSh 25,000 – 35,000</option><option>KSh 35,000 – 60,000</option><option>KSh 60,000+</option><option>Not sure yet</option></select></label>'
		. '<label class="et-field"><span>When do you need it?</span><select name="when"><option>As soon as possible</option><option>Within 2 weeks</option><option>Within a month</option><option>No rush</option></select></label>'
		. '<label class="et-field et-field--wide et-file"><span>Reference photo (optional)</span><input type="file" name="photo" accept="image/*"></label>'
		. '<label class="et-field et-field--wide"><span>Or a link (Instagram post, website…)</span><input name="link" type="url" placeholder="https://"></label>'
		. ( $compact ? '' : '<label class="et-field et-field--wide"><span>Anything else?</span><textarea name="notes" rows="3" placeholder="Dial colour, strap, wrist size, a gift…"></textarea></label>' )
		. '<button class="wp-element-button et-field--wide" type="submit">Send sourcing request</button>'
		. '<p class="et-small et-field--wide">We reply on WhatsApp with options, photos and a price before anything is ordered.</p>'
		. '</form>';
}

add_action( 'admin_post_nopriv_et_source', 'et_source' );
add_action( 'admin_post_et_source', 'et_source' );
function et_source() {
	check_admin_referer( 'et_source' );
	$f     = fn( $k ) => sanitize_text_field( wp_unslash( $_POST[ $k ] ?? '' ) );
	$want  = $f( 'want' );
	$name  = $f( 'name' );
	$phone = $f( 'phone' );
	$ajax  = ! empty( $_POST['ajax'] );
	if ( $want === '' || $name === '' || $phone === '' ) {
		if ( $ajax ) {
			wp_send_json_error( [ 'message' => 'Please fill in the watch, your name and your phone number.' ], 400 );
		}
		wp_safe_redirect( home_url( '/sourcing-desk/?et_src=missing#source' ) );
		exit;
	}
	$code  = 'SRC-' . strtoupper( wp_generate_password( 5, false, false ) );
	$link  = esc_url_raw( wp_unslash( $_POST['link'] ?? '' ) );
	$lines = [ 'Watch: ' . $want, 'Name: ' . $name, 'Phone: ' . $phone, 'Budget: ' . $f( 'budget' ), 'When: ' . $f( 'when' ) ];
	if ( $link ) {
		$lines[] = 'Link: ' . $link;
	}
	$notes = sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) );
	if ( $notes ) {
		$lines[] = 'Notes: ' . $notes;
	}

	$id = wp_insert_post( [ 'post_type' => 'et_request', 'post_status' => 'private', 'post_title' => $code . ' – ' . $want . ' (' . $name . ')', 'post_content' => implode( "\n", $lines ) ] );
	$photo_url = '';
	if ( $id && ! empty( $_FILES['photo']['name'] ) && empty( $_FILES['photo']['error'] ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$type = wp_check_filetype( $_FILES['photo']['name'] );
		if ( $type['type'] && str_starts_with( $type['type'], 'image/' ) && $_FILES['photo']['size'] < 8 * MB_IN_BYTES ) {
			$att = media_handle_upload( 'photo', $id );
			if ( ! is_wp_error( $att ) ) {
				$photo_url = wp_get_attachment_url( $att );
				wp_update_post( [ 'ID' => $id, 'post_content' => implode( "\n", $lines ) . "\n\n" . '<img src="' . esc_url( $photo_url ) . '" alt="Reference photo" style="max-width:420px">' ] );
			}
		}
	}

	$wa_lines = array_merge( [ 'Hi Eli\'s TimeShiftKE, sourcing request ' . $code . ':' ], $lines );
	if ( $photo_url ) {
		$wa_lines[] = 'Reference photo: ' . $photo_url;
	}
	$wa = et_wa_link( implode( "\n", $wa_lines ) );
	if ( $ajax ) {
		wp_send_json_success( [ 'code' => $code, 'wa' => $wa ] );
	}
	set_transient( 'et_src_' . $code, $wa, DAY_IN_SECONDS );
	wp_safe_redirect( add_query_arg( [ 'et_src' => 'ok', 'code' => $code ], home_url( '/sourcing-desk/' ) ) . '#source' );
	exit;
}

add_shortcode( 'et_sourcing_page', function () {
	$state = sanitize_key( $_GET['et_src'] ?? '' );
	$code  = sanitize_text_field( wp_unslash( $_GET['code'] ?? '' ) );
	$body  = et_sourcing_form();
	$wa    = $state === 'ok' && $code ? get_transient( 'et_src_' . $code ) : '';
	if ( $wa ) {
		$body = '<div class="et-src-done"><p class="et-eyebrow">Request received ✓</p><h3>Reference ' . esc_html( $code ) . '</h3><p>Our sourcing desk has your request. For the fastest reply, send it to us on WhatsApp as well.</p><a class="wp-element-button et-wa-btn" href="' . esc_url( $wa ) . '" target="_blank" rel="noopener">Send request on WhatsApp</a></div>';
	} elseif ( $state === 'missing' ) {
		$body = '<p class="et-news-err">Please fill in the watch, your name and your phone number.</p>' . $body;
	}
	return '<div class="et-src-page">'
		. '<div class="et-src-page__intro"><p class="et-eyebrow">Sourcing desk 🔌</p><h2>Can\'t find your grail watch? We\'ll find it.</h2><p>Send us a reference picture or a link and our sourcing team finds the piece for you, brand new. We come back with photos, a price and a delivery date, and you pay on delivery.</p>'
		. '<ol class="et-steps"><li><strong>Send the reference</strong>A photo, a link, or just describe it.</li><li><strong>We find it</strong>Options, photos and a price on WhatsApp.</li><li><strong>You confirm</strong>We order it in and tell you the arrival date.</li><li><strong>Pay on delivery</strong>Free in Nairobi, countrywide by parcel.</li></ol></div>'
		. '<div id="source" class="et-src-page__form">' . $body . '</div></div>';
} );

/* -------------------------------------------------------------------------
 * Cart, checkout, order confirmation
 * ---------------------------------------------------------------------- */

function et_cart_note_html() {
	return '<div class="et-cart-note"><strong>FREE Nairobi delivery applied at checkout 🔌</strong> Payment on delivery 📦: pay by M-Pesa or cash when it arrives.</div>';
}
function et_wa_cart_html() {
	return '<button type="button" class="et-wa-cart" data-et-wa-cart>' . ET_WA_ICON . 'Send this cart on WhatsApp</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => et_cart_note_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . et_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-filled-mini-cart-contents-block[^>]*>)#', '$1' . et_cart_note_html(), $c, 1 );
} );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="et-wa-cart-wrap">' . et_wa_cart_html() . '</div>' );

// A landmark helps the rider; packaging is complimentary, a gift note is optional.
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	woocommerce_register_additional_checkout_field( [
		'id'       => 'et/landmark',
		'label'    => 'Building, office or nearest landmark',
		'location' => 'address',
		'type'     => 'text',
		'required' => false,
	] );
	woocommerce_register_additional_checkout_field( [
		'id'       => 'et/gift-note',
		'label'    => 'Gift note for the box',
		'location' => 'order',
		'type'     => 'text',
		'required' => false,
	] );
} );

// Tracking code and WhatsApp summary on the order confirmation page.
function et_tracking_code( WC_Order $order ) {
	return 'ETS-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
function et_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Eli\'s TimeShiftKE, I just placed order ' . et_tracking_code( $order ) . ':' ];
	foreach ( $order->get_items() as $item ) {
		$lines[] = '• ' . $item->get_name() . ( $item->get_quantity() > 1 ? ' ×' . $item->get_quantity() : '' ) . ' – ' . et_money( $item->get_total() );
	}
	foreach ( $order->get_fees() as $fee ) {
		$lines[] = '• ' . $fee->get_name() . ' – ' . et_money( $fee->get_total() );
	}
	foreach ( $order->get_coupon_codes() as $code ) {
		$lines[] = 'Promo code: ' . strtoupper( $code );
	}
	$lines[] = 'Total: ' . et_money( $order->get_total() );
	$lines[] = 'Delivery: ' . $order->get_shipping_method();
	$address = trim( implode( ', ', array_filter( [ $order->get_shipping_address_1(), $order->get_shipping_city() ] ) ) );
	if ( $address ) {
		$lines[] = 'Deliver to: ' . $address;
	}
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return et_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) {
		return $content;
	}
	return $content . '<div class="et-thanks"><p class="et-thanks__code">Tracking code <strong>' . esc_html( et_tracking_code( $order ) ) . '</strong></p><p>We\'ll call you shortly to confirm and arrange delivery. You pay by M-Pesa or cash when it arrives. For the quickest reply, send your order summary to us on WhatsApp.</p><a class="wp-element-button et-wa-btn" href="' . esc_attr( et_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">Send order summary to WhatsApp</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Tracking code:</strong> ' . esc_html( et_tracking_code( $order ) ) . '</p>';
} );

// VIP Collector Club: sourcing alerts and new drops. Staff see the list under WooCommerce → VIP Club.
add_action( 'admin_post_nopriv_et_subscribe', 'et_subscribe' );
add_action( 'admin_post_et_subscribe', 'et_subscribe' );
function et_subscribe() {
	check_admin_referer( 'et_subscribe' );
	$contact = sanitize_text_field( wp_unslash( $_POST['contact'] ?? '' ) );
	$back    = wp_get_referer() ?: home_url( '/' );
	if ( ! is_email( $contact ) && ! preg_match( '/^\+?[0-9 ]{9,15}$/', $contact ) ) {
		wp_safe_redirect( add_query_arg( 'et_sub', 'invalid', $back ) . '#newsletter' );
		exit;
	}
	$list = get_option( 'et_subscribers', [] );
	$list[ strtolower( $contact ) ] = current_time( 'mysql' );
	update_option( 'et_subscribers', $list, false );
	wp_safe_redirect( add_query_arg( 'et_sub', 'ok', $back ) . '#newsletter' );
	exit;
}

add_shortcode( 'et_newsletter', function () {
	$state = sanitize_key( $_GET['et_sub'] ?? '' );
	if ( $state === 'ok' ) {
		return '<p class="et-news-ok"><strong>Welcome to the VIP Club.</strong> New drops and sourcing alerts reach you before they go on Instagram.</p>';
	}
	$err = $state === 'invalid' ? '<p class="et-news-err">Please enter an email address or a phone number.</p>' : '';
	return '<form class="et-news-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
		. '<input type="hidden" name="action" value="et_subscribe">'
		. wp_nonce_field( 'et_subscribe', '_wpnonce', true, false )
		. '<input type="text" name="contact" required placeholder="Email or WhatsApp number" aria-label="Email or WhatsApp number">'
		. '<button class="wp-element-button" type="submit">Join the club</button>'
		. '</form>' . $err;
} );

add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'VIP Club', 'VIP Club', 'manage_woocommerce', 'et-subscribers', function () {
		$list = get_option( 'et_subscribers', [] );
		echo '<div class="wrap"><h1>VIP Collector Club (' . count( $list ) . ')</h1><table class="widefat striped"><thead><tr><th>Email or phone</th><th>Joined</th></tr></thead><tbody>';
		foreach ( array_reverse( $list, true ) as $c => $when ) {
			echo '<tr><td>' . esc_html( $c ) . '</td><td>' . esc_html( $when ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	} );
} );

// Staff edit condition, specs and the sample flag on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_et_condition', 'label' => 'Condition', 'description' => 'e.g. "Brand new".', 'desc_tip' => true ] );
	woocommerce_wp_textarea_input( [ 'id' => '_et_specs', 'label' => 'Specifications', 'rows' => 8, 'description' => 'One per line, as "Label: value", e.g. "Case: Stainless steel, 41 mm". Case, Movement, Water resistance and Glass also show next to the price.' ] );
	woocommerce_wp_checkbox( [ 'id' => '_et_sample', 'label' => 'Sample listing', 'description' => 'Demo watch: shows a "Sample" badge. Untick (or delete the product) for real stock.', 'cbvalue' => 'yes' ] );
	echo '<p class="form-field"><em>Availability: tag the watch "In $tores" or "PRE-ORDER$" (Product tags box). For pre-orders, set stock to 0 and allow backorders. Movement and strap are under Attributes.</em></p>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_et_condition' => 'sanitize_text_field', '_et_specs' => 'sanitize_textarea_field' ] as $key => $clean ) {
		if ( isset( $_POST[ $key ] ) ) {
			$product->update_meta_data( $key, $clean( wp_unslash( $_POST[ $key ] ) ) );
		}
	}
	$product->update_meta_data( '_et_sample', isset( $_POST['_et_sample'] ) ? 'yes' : 'no' );
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode, and we need a phone number to arrange delivery.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['city']     = [ 'label' => 'Estate / Area / Town (e.g. Kilimani, Westlands, Nakuru)' ];
	$locale['KE']['phone']    = [ 'required' => true ];
	return $locale;
} );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#0B0C10\">\n";
} );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src)="/(?!/)#', '$1="' . $home, $content );
} );
